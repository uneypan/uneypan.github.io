# In foo_script.py
import foo


def main():
    pass

if __name__ == "__main__":
    main()
